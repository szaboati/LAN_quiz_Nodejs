const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const bodyParser = require("body-parser");
const fs = require("fs");
const path = require("path");

const app = express();
const db = new sqlite3.Database("./db.sqlite");

// Beállítások
const TEACHER_PASSWORD = "bossboss";
const DEFAULT_QUIZ_FILE = "questions-github.json";
const CURRENT_QUIZ_STATE = "./current-quiz.txt";

app.use(bodyParser.json());
app.use(express.static("public"));

function readCurrentQuizFile() {
  try {
    const name = fs.readFileSync(CURRENT_QUIZ_STATE, "utf8").trim();
    return name || DEFAULT_QUIZ_FILE;
  } catch {
    return DEFAULT_QUIZ_FILE;
  }
}

function writeCurrentQuizFile(name) {
  fs.writeFileSync(CURRENT_QUIZ_STATE, name, "utf8");
}

let currentQuizFile = readCurrentQuizFile();

function quizFilePath(name) {
  return path.join(__dirname, name);
}

// Tanári beállítás
app.post("/setquiz", (req, res) => {
  const { file, password } = req.body;
  if (password !== TEACHER_PASSWORD) {
    return res.status(403).json({ error: "Hibás jelszó" });
  }
  const fullPath = quizFilePath(file);
  if (!fs.existsSync(fullPath)) {
    return res.status(400).json({ error: "Nincs ilyen kérdésfájl: " + file });
  }
  currentQuizFile = file;
  writeCurrentQuizFile(file);
  return res.json({ status: "ok", currentQuizFile });
});

// Diák bejelentkezés
app.post("/login", (req, res) => {
  const { user } = req.body;
  if (!user || !user.trim()) {
    return res.status(400).json({ error: "Név kötelező" });
  }
  const cleanUser = user.trim();
  db.run("INSERT OR IGNORE INTO users(id) VALUES(?)", [cleanUser], (err) => {
    if (err) return res.status(500).json({ error: "Adatbázis hiba" });
    return res.json({ status: "ok", user: cleanUser });
  });
});

// Kvíz kérdések
app.get("/quiz", (req, res) => {
  try {
    const data = fs.readFileSync(quizFilePath(currentQuizFile), "utf8");
    const questions = JSON.parse(data);
    const shuffled = questions.sort(() => Math.random() - 0.5);
    return res.json(shuffled);
  } catch (e) {
    return res.status(500).json({ error: "Kérdések betöltése sikertelen" });
  }
});

// Válasz beküldése (egyszeri kitöltés)
app.post("/answer", (req, res) => {
  const { user, questionId, answer } = req.body;
  if (!user || !questionId || typeof answer === "undefined") {
    return res.status(400).json({ error: "Hiányzó adatok" });
  }

  try {
    const data = fs.readFileSync(quizFilePath(currentQuizFile), "utf8");
    const questions = JSON.parse(data);
    const q = questions.find(q => q.id === Number(questionId));
    if (!q) return res.status(404).json({ error: "Nincs ilyen kérdés" });
    const correct = q.correct === answer ? 1 : 0;

    db.get("SELECT * FROM answers WHERE user=? AND question=?", [user, questionId], (err, row) => {
      if (err) return res.status(500).json({ error: "Adatbázis hiba" });
      if (row) {
        return res.json({ message: "Már válaszoltál erre a kérdésre", correct: row.correct });
      } else {
        db.run(
          "INSERT INTO answers(user, question, answer, correct) VALUES(?,?,?,?)",
          [user, questionId, answer, correct],
          (err) => {
            if (err) return res.status(500).json({ error: "Adatbázis hiba" });
            return res.json({ correct });
          }
        );
      }
    });
  } catch (e) {
    return res.status(500).json({ error: "Kérdések betöltése sikertelen" });
  }
});

// Tanári összesítés
app.get("/results", (req, res) => {
  db.all("SELECT user, SUM(correct) AS score FROM answers GROUP BY user", (err, rows) => {
    if (err) return res.status(500).json({ error: "Adatbázis hiba" });
    return res.json(rows);
  });
});

// Diák saját eredménye
app.get("/myresult/:user", (req, res) => {
  const user = req.params.user;
  db.get("SELECT SUM(correct) AS score FROM answers WHERE user=?", [user], (err, row) => {
    if (err) return res.status(500).json({ error: "Adatbázis hiba" });
    return res.json({ user, score: row && row.score ? row.score : 0 });
  });
});

// Diák részletes eredménye
app.get("/mydetails/:user", (req, res) => {
  const user = req.params.user;
  try {
    const data = fs.readFileSync(quizFilePath(currentQuizFile), "utf8");
    const questions = JSON.parse(data);
    const questionMap = new Map(questions.map(q => [q.id, q]));

    db.all("SELECT * FROM answers WHERE user=?", [user], (err, rows) => {
      if (err) return res.status(500).json({ error: "Adatbázis hiba" });
      const detailed = rows.map(a => {
        const q = questionMap.get(a.question) || {};
        return {
          text: q.text,
          optionA: q.optionA,
          optionB: q.optionB,
          optionC: q.optionC,
          optionD: q.optionD,
          correct: q.correct,
          answer: a.answer,
          isCorrect: a.correct === 1
        };
      });
      return res.json(detailed);
    });
  } catch {
    return res.status(500).json({ error: "Kérdések betöltése sikertelen" });
  }
});

app.listen(3000, () => {
  console.log("Quiz szerver fut a 3000 porton");
});
