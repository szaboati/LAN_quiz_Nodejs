let currentUser = null;

function login() {
  const user = document.getElementById("user").value.trim();
  if (!user) return alert("Add meg a neved!");
  fetch("/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ user })
  })
  .then(res => res.json())
  .then(data => {
    if (data.error) return alert(data.error);
    currentUser = user;
    loadQuiz();
  });
}

function loadQuiz() {
  fetch("/quiz")
    .then(res => res.json())
    .then(questions => {
      const container = document.getElementById("quiz");
      container.innerHTML = "";
      questions.forEach((q, index) => {
        const block = document.createElement("div");
        block.style.margin = "12px 0";
        block.innerHTML = `
          <strong>${index + 1}. ${q.text}</strong><br>
          <label><input type="radio" name="q${q.id}" value="${q.optionA}"> ${q.optionA}</label><br>
          <label><input type="radio" name="q${q.id}" value="${q.optionB}"> ${q.optionB}</label><br>
          <label><input type="radio" name="q${q.id}" value="${q.optionC}"> ${q.optionC}</label><br>
          <label><input type="radio" name="q${q.id}" value="${q.optionD}"> ${q.optionD}</label>
        `;
        container.appendChild(block);
      });
    });
}

function showMyResult() {
  // Beküldjük az összes választ
  const blocks = document.querySelectorAll("#quiz > div");
  const promises = [];
  blocks.forEach(block => {
    const name = block.querySelector("input[type=radio]")?.name;
    const selected = document.querySelector(`input[name="${name}"]:checked`);
    if (!selected) return; // kihagyott kérdés
    const questionId = Number(name.replace("q", ""));
    const answer = selected.value;
    promises.push(fetch("/answer", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user: currentUser, questionId, answer })
    }).then(res => res.json()));
  });

  Promise.all(promises).then(() => {
    fetch(`/myresult/${encodeURIComponent(currentUser)}`)
      .then(res => res.json())
      .then(r => {
        document.getElementById("finalResult").innerText =
          `${r.user} pontszáma: ${r.score || 0}`;
      });
  });
}

function showMyDetails() {
  fetch(`/mydetails/${encodeURIComponent(currentUser)}`)
    .then(res => res.json())
    .then(rows => {
      const d = document.getElementById("details");
      d.innerHTML = "";
      rows.forEach((r, index) => {
        const p = document.createElement("p");
        p.innerHTML = `
          <strong>${index + 1}. ${r.text}</strong><br>
          Válaszod: ${r.answer} | Helyes: ${r.correct} | ${r.isCorrect ? "✓" : "✗"}
        `;
        d.appendChild(p);
      });
    });
}

function loadResults() {
  fetch("/results")
    .then(res => res.json())
    .then(rows => {
      const ul = document.getElementById("results");
      ul.innerHTML = "";
      rows.forEach(r => {
        const li = document.createElement("li");
        li.textContent = `${r.user}: ${r.score || 0} pont`;
        ul.appendChild(li);
      });
    });
}
