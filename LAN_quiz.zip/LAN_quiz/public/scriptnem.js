let currentUser = null;

function login() {
  const user = document.getElementById("user").value.trim();
  if (!user) return alert("Add meg a neved!");
  fetch("/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ user })
  })
  .then(res => res.json())
  .then(data => {
    if (data.error) return alert(data.error);
    currentUser = user;
    loadQuiz();
  });
}

function loadQuiz() {
  fetch("/quiz")
    .then(res => res.json())
    .then(questions => {
      const container = document.getElementById("quiz");
      container.innerHTML = "";
      questions.forEach((q, index) => {
        const block = document.createElement("div");
        block.style.margin = "12px 0";
        block.innerHTML = `
          <strong>${index + 1}. ${q.text}</strong><br>
          <label><input type="radio" name="q${q.id}" value="${q.optionA}"> ${q.optionA}</label><br>
          <label><input type="radio" name="q${q.id}" value="${q.optionB}"> ${q.optionB}</label><br>
          <label><input type="radio" name="q${q.id}" value="${q.optionC}"> ${q.optionC}</label><br>
          <label><input type="radio" name="q${q.id}" value="${q.optionD}"> ${q.optionD}</label>
        `;
        container.appendChild(block);
      });
    });
}

function showMyResult() {
  const blocks = document.querySelectorAll("#quiz > div");
  const promises = [];
  blocks.forEach(block => {
    const name = block.querySelector("input[type=radio]")?.name;
    const selected = document.querySelector(`input[name="${name}"]:checked`);
    if (!selected) return;
    const questionId = Number(name.replace("q", ""));
    const answer = selected.value;
    promises.push(fetch("/answer", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user: currentUser, questionId, answer })
    }).then(res => res.json()));
  });

  Promise.all(promises).then(results => {
    // Ha valaki újra próbálkozna, üzenetet kap
    results.forEach(r => {
      if (r.message) {
        alert(r