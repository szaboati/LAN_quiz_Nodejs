const sqlite3 = require("sqlite3").verbose();
const db = new sqlite3.Database("./db.sqlite");

db.serialize(() => {
  db.run("CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY)");
  db.run(`CREATE TABLE IF NOT EXISTS questions (
    id INTEGER PRIMARY KEY,
    text TEXT,
    optionA TEXT,
    optionB TEXT,
    optionC TEXT,
    optionD TEXT,
    correct TEXT
  )`);
  db.run("CREATE TABLE IF NOT EXISTS answers (user TEXT, question INTEGER, answer TEXT, correct INTEGER)");

  // Tiszta indulás
  db.run("DELETE FROM users");
  db.run("DELETE FROM answers");
});

db.close();
